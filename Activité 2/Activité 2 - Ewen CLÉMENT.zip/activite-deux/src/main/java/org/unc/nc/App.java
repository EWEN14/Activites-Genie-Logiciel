package org.unc.nc;

/**
 * Hello world.
 */
public class App {
  /**
   * Simple Hello World.
   *
   * @param args arguments
   */
  public static void main(final String[] args) {
    System.out.println("Hello World!");
  }
}
