package org.unc.nc.exceptions;

public class CaractereInterditException extends Exception {

  public CaractereInterditException(String errorMessage) {
    super(errorMessage);
  }
}
