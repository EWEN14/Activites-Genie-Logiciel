package org.unc.nc.exceptions;

public class HorsBornesException extends Exception {

  public HorsBornesException(String errorMessage)  {
    super(errorMessage);
  }
}
