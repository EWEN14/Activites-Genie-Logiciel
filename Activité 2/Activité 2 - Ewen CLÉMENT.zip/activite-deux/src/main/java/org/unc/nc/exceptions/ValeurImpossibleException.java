package org.unc.nc.exceptions;

public class ValeurImpossibleException extends Exception {

  public ValeurImpossibleException(String errorMessage) {
    super(errorMessage);
  }
}
